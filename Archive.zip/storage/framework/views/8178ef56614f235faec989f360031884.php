<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-3 gap-8">
    <!-- Main Content -->
    <div class="col-span-2">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white p-8 mb-8 rounded-lg shadow-sm">
                <h2 class="text-3xl font-bold mb-3">
                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="hover:text-blue-600">
                        <?php echo e($post->title); ?>

                    </a>
                </h2>
                
                <p class="text-gray-600 text-sm mb-6">
                    Posted on <?php echo e($post->published_at->format('F j, Y')); ?> by 
                    <span class="text-pink-600 font-semibold"><?php echo e($post->author->display_name); ?></span>
                </p>

                <p class="text-gray-700 leading-relaxed mb-6">
                    <?php echo e($post->excerpt ?? Str::limit(strip_tags($post->content), 200)); ?>

                </p>

                <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="text-gray-600 hover:text-gray-800 font-semibold">
                    Read More →
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="bg-white p-8 rounded-lg shadow-sm text-center text-gray-600">
                No posts found.
            </div>
        <?php endif; ?>

        <!-- Pagination -->
        <div class="mt-8 flex justify-center">
            <?php echo e($posts->links()); ?>

        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-span-1">
        <!-- Search -->
        <div class="bg-white p-6 rounded-lg shadow-sm mb-6">
            <h3 class="section-title font-bold text-lg">Search This Blog</h3>
            <form method="GET" action="<?php echo e(route('blog.search')); ?>" class="flex gap-2">
                <input type="text" name="q" placeholder="Search..." class="flex-1 px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                <button type="submit" class="bg-blue-400 text-white px-6 py-2 rounded hover:bg-blue-500 font-semibold">
                    Go
                </button>
            </form>
        </div>

        <!-- Categories -->
        <div class="bg-white p-6 rounded-lg shadow-sm mb-6">
            <h3 class="section-title font-bold text-lg">Categories</h3>
            <select class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                <option>Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Archives -->
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <h3 class="section-title font-bold text-lg">Archives</h3>
            <select class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                <option>Select Month</option>
                <!-- You can add archive functionality here -->
            </select>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/victoranimasahun/Desktop/laravel-projects/blog.slslanguage.com/resources/views/blog/index.blade.php ENDPATH**/ ?>