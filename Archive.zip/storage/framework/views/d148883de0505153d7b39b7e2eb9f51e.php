<?php
// Database configuration
//require_once 'config.php';

// Fetch recent posts
$posts_query = "SELECT p.*, u.username, u.display_name 
                FROM posts p 
                JOIN users u ON p.author_id = u.id 
                WHERE p.status = 'published' 
                ORDER BY p.created_at DESC 
                LIMIT 10";
$posts = $db->query($posts_query)->fetchAll();

// Fetch categories
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories = $db->query($categories_query)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SLS Blog - Scholarly Language Services</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f5f5;
        }

        .header {
            background: #fff;
            border-bottom: 3px solid #38b6ff;
            padding: 1rem 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .logo-area {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #38b6ff 0%, #ff66c4 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: white;
            font-size: 20px;
            border-radius: 8px;
        }

        .logo-text h1 {
            font-size: 28px;
            color: #333;
        }

        .logo-text h1 .sls {
            color: #38b6ff;
        }

        .logo-text h1 .blog {
            color: #ff66c4;
        }

        .logo-text p {
            font-size: 11px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .social-links {
            display: flex;
            gap: 15px;
        }

        .social-links a {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: #38b6ff;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
        }

        .social-links a:hover {
            background: #ff66c4;
        }

        .nav-bar {
            background: #38b6ff;
            padding: 0.5rem 0;
        }

        .nav-bar ul {
            list-style: none;
            display: flex;
            gap: 5px;
        }

        .nav-bar a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            display: block;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .nav-bar a:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .main-content {
            display: grid;
            grid-template-columns: 1fr 300px;
            gap: 30px;
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .posts-area {
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }

        .post-card {
            padding: 30px;
            border-bottom: 1px solid #e0e0e0;
        }

        .post-card:last-child {
            border-bottom: none;
        }

        .post-title {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .post-title a {
            color: #333;
            text-decoration: none;
        }

        .post-title a:hover {
            color: #38b6ff;
        }

        .post-meta {
            color: #888;
            font-size: 13px;
            margin-bottom: 15px;
        }

        .post-meta a {
            color: #ff66c4;
            text-decoration: none;
        }

        .post-excerpt {
            color: #555;
            line-height: 1.8;
        }

        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .widget {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .widget h3 {
            color: #38b6ff;
            margin-bottom: 15px;
            font-size: 18px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ff66c4;
        }

        .search-box {
            display: flex;
            gap: 5px;
        }

        .search-box input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .search-box button {
            background: #38b6ff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .search-box button:hover {
            background: #ff66c4;
        }

        .widget select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            background: white;
        }

        .widget ul {
            list-style: none;
        }

        .widget ul li {
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .widget ul li:last-child {
            border-bottom: none;
        }

        .widget ul li a {
            color: #555;
            text-decoration: none;
            transition: color 0.3s;
        }

        .widget ul li a:hover {
            color: #38b6ff;
        }

        .no-posts {
            text-align: center;
            padding: 60px 20px;
            color: #888;
        }

        .footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 40px;
        }

        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }

            .logo-area {
                justify-content: center;
                text-align: center;
            }

            .logo {
                margin-bottom: 15px;
            }

            .nav-bar ul {
                flex-wrap: wrap;
                justify-content: center;
            }

            .post-card {
                padding: 20px;
            }

            .post-title {
                font-size: 20px;
            }
        }
    </style>
</head>
	<body>
		<h1>Blog Posts</h1>

		
		<aside>
			<h3>Categories</h3>
			<ul>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($category->name); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</aside>

		
		<main>
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<article>
					<h2><?php echo e($post->title); ?></h2>
					<p>By <strong><?php echo e($post->author->name); ?></strong></p>
					<p><?php echo e($post->content); ?></p>
					<small>Published: <?php echo e($post->created_at->format('F j, Y')); ?></small>
				</article>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</main>
	</body>
</html><?php /**PATH /Users/victoranimasahun/Desktop/laravel-projects/blog.slslanguage.com/resources/views/home.blade.php ENDPATH**/ ?>